<div class="card">
  <div class="card-image">
    <img src="<?php echo e($imagem); ?>">
  </div>
  <div class="card-stacked">
    <div class="card-content">
      <h5 class="header"><?php echo e($titulo); ?></h5>
      <p><?php echo e($descricao); ?></p>
      <strong><?php echo e($valor); ?></strong>
    </div>
    <div class="card-action">
      <a href="<?php echo e($url); ?>">Ver mais</a>
    </div>
  </div>
</div>
