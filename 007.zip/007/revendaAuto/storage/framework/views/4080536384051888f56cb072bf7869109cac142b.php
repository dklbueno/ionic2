<?php $__env->startSection('content'); ?>

  <?php $__env->startComponent('componentes.slide',['lista'=>$slides]); ?>
  <?php echo $__env->renderComponent(); ?>

<div class="container">
  <?php $__env->startComponent('componentes.lista_cartao',['lista'=>$carros,'tamanho'=>'4']); ?>
  <?php echo $__env->renderComponent(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>