import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ICarro } from '../../interfaces/icarro';
/*
  Generated class for the Detalhe page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-detalhe',
  templateUrl: 'detalhe.html'
})
export class DetalhePage {
  public carro:ICarro;

  public imagemPadrao:string = 'https://maxcdn.icons8.com/Share/icon/Transport//car1600.png';

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.carro = this.navParams.get('carro');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DetalhePage');
  }

}
