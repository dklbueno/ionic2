import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';

import { ICarro } from '../interfaces/icarro';

/*
  Generated class for the CarroService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class CarroService {

  public carroUrl = 'http://127.0.0.1:8000/api/carros';
  constructor(public http: Http) {
    console.log('Hello CarroService Provider');
  }

  listaCarros():Observable<ICarro[]>{
    return this.http.get(this.carroUrl).map(res => res.json()).catch(this.erro);
  }

  erro(error) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }




}
