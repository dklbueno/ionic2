$(document).ready(function() {
  Materialize.updateTextFields();
  $('.slider').slider({full_width: true});
  $('select').material_select();
});
