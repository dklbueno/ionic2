<div class="row">
  <?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col s12 m<?php echo e($tamanho); ?>">
      <?php $__env->startComponent('componentes.cartao',[
        'titulo'=>$value->titulo,
        'descricao'=>$value->descricao,
        'imagem'=>$value->imagem,
        'valor'=>$value->valor,
        'url'=>$value->url]
        ); ?>

      <?php echo $__env->renderComponent(); ?>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
