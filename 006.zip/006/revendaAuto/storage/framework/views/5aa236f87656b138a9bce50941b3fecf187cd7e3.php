<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <h2 class="center">Cadastro do Sistema</h2>
      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
          <?php echo e(csrf_field()); ?>


          <div class="input-field col s12">
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="validate" autofocus>
            <label>Nome</label>
            <?php if($errors->has('name')): ?>
                <span>
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="input-field col s12">
            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="validate">
            <label>E-mail</label>
            <?php if($errors->has('email')): ?>
                <span>
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="input-field col s12">
            <input type="password"  name="password" value="<?php echo e(old('password')); ?>" class="validate">
            <label>Senha</label>
            <?php if($errors->has('password')): ?>
                <span>
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="input-field col s12">
            <input type="password"  name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" class="validate">
            <label>Confirme a senha</label>
            <?php if($errors->has('password_confirmation')): ?>
                <span>
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="col s12">
            <br/>
            <button class="btn green">Cadastrar</button>
          </div>
      </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>