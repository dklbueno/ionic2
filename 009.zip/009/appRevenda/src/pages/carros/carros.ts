import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { CarroService } from '../../providers/carro-service';

/*
  Generated class for the Carros page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-carros',
  templateUrl: 'carros.html'
})
export class CarrosPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public carroService: CarroService) {
    this.carroService.listaCarros().subscribe(data => {
      console.log(data);
    },erro =>{
      console.log(erro);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CarrosPage');
  }

}
