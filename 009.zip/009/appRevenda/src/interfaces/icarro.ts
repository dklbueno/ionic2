export interface ICarro {
  id?:number;
  titulo:string;
  ano:string;
  valor:string;
  created_at:string;
  updated_at:string;
  marca_id:string;
  marca:any;
  categorias:any;
  imagens:any;
}
