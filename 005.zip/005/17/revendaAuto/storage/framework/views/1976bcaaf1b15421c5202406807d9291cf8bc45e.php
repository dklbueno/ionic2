<?php $__env->startSection('content'); ?>

<div class="container">
    <div id="destaques" class="row section scrollspy">
      <div class="col s12 m6">
        <?php $__env->startComponent('componentes.slide',['lista'=>$galeria]); ?>
        <?php echo $__env->renderComponent(); ?>
      </div>

      <div class="col s12 m6">

        <h3 class="center">Contato:</h3>
        <form>
          <div class="input-field col s12">
            <input type="text" class="validate">
            <label>Nome</label>
          </div>
          <div class="input-field col s12">
            <input type="email" class="validate">
            <label>E-mail</label>
          </div>
          <div class="input-field col s12">
            <textarea class="materialize-textarea"></textarea>
            <label>Mensagem</label>
          </div>
          <div class="input-field col s12">
            <button  class="waves-effect waves-light btn">Enviar</button>
          </div>
        </form>
      </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>